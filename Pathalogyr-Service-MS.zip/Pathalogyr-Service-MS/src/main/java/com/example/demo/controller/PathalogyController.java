package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.DiseasesList;
import com.example.demo.model.Pathalogy;

@RestController
@RequestMapping("/path")
public class PathalogyController {
	
	List<Pathalogy> pathalogy =Arrays.asList(
			new Pathalogy("d1","fever","t1"),
			new Pathalogy("d2","cold","t2"),
			new Pathalogy("d3","headach","t3")
			
			);
			
	/*
	 * //http://localhost:8083/path/pathalogy
	 * 
	 * @RequestMapping("/pathalogy") public List<Pathalogy> getAddmissions() {
	 * return pathalogy; }
	 */
		
	
	
	//http://localhost:8083/path/pathalogy
	@RequestMapping("/pathalogy")
	public DiseasesList getPathalogy()
	{
		DiseasesList diseasesList= new DiseasesList();
		diseasesList.setDiesease(pathalogy);
		return diseasesList;
	}
	
	//http://localhost:8083/path/pathalogy/d2
			
   @RequestMapping("/pathalogy/{Id}")

   public Pathalogy getPathalogyById(@PathVariable("Id") String Id)
   {
	   Pathalogy e= pathalogy.stream()
			   .filter(pathalogy -> Id.equals(pathalogy.getId()))
			   .findAny()
			   .orElse(null);
	   return e;
   }
	
   

	
}

