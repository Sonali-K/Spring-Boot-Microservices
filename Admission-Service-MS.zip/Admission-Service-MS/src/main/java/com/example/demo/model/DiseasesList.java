package com.example.demo.model;

import java.util.List;

public class DiseasesList {
	
	public List<Pathalogy>  diesease;

	public List<Pathalogy> getDiesease() {
		return diesease;
	}

	public void setDiesease(List<Pathalogy> diesease) {
		this.diesease = diesease;
	}
	
	

}
