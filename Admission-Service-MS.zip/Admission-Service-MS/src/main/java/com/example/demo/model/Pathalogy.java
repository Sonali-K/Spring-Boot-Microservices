package com.example.demo.model;

public class Pathalogy {
	
	private String id;
	private String descripation;
	
	private String treatments;

	public Pathalogy() {
		
	}

	public Pathalogy(String id, String descripation, String treatments) {
		super();
		this.id = id;
		this.descripation = descripation;
		this.treatments = treatments;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescripation() {
		return descripation;
	}

	public void setDescripation(String descripation) {
		this.descripation = descripation;
	}

	public String getTreatments() {
		return treatments;
	}

	public void setTreatments(String treatments) {
		this.treatments = treatments;
	}

	
	

}
