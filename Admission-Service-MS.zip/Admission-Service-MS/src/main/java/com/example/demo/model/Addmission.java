package com.example.demo.model;

public class Addmission {
	
	private String id;
	private String name;
	
	private String position;

	public Addmission() {
		
	}

	public Addmission(String id, String name, String position) {
		super();
		this.id = id;
		this.name = name;
		this.position = position;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	

}
