package com.example.demo;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
class HelloTestApplicationTests {

	private MockMvc mockMvc;
	@InjectMocks
	HelloTestApplicationTests helloTestApplicationTests;
	
	@Before
	public void setUp() throws Exception{
		mockMvc =MockMvcBuilders.standaloneSetup(helloTestApplicationTests)
				.build();
	}
	
	@Test
	void contextLoads() throws Exception{
		mockMvc.perform(MockMvcRequestBuilders.get("/hello/hi"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.content().string("Hello"));
		
	}

}
