package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.model.EmployeesList;

@RestController
@RequestMapping("/hr")
public class HrController {

	List<Employee> employees= Arrays.asList(
			new Employee("e1","Ram","Pune"),
			new Employee("e2","Radha","Mumbai"),
			new Employee("e3","Ramesh","Baramati")
			
			
			);
	
	
	/*
	 * //http://localhost:8082/hr/employees
	 * 
	 * @RequestMapping("/employees") public List<Employee> getAddmissions() { return
	 * employees; }
	 */
	
	//http://localhost:8082/hr/employees
	@RequestMapping("/employees")
	public EmployeesList getEmployees()
	{
		EmployeesList employeesList = new EmployeesList();
		employeesList.setEmployees(employees);
	return employeesList;
	}
	
	//http://localhost:8082/hr/employees/e1
	@RequestMapping("/employees/{Id}")
	public Employee getEmployeeById(@PathVariable("Id") String Id)
	{
		Employee e= employees.stream()
				.filter(employee -> Id.equals(employee.getId()))
				.findAny()
				.orElse(null);
		return e;
	}
	
	
}
